...
public class DetailFragment extends Fragment implements LoaderManager.LoaderCallbacks<Cursor> {
private WindView mWindGraphic;
...
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
...
        mWindGraphic = (WindView) rootView.findViewById(R.id.detail_wind_graphic);
...
    }
...
    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
...
            // Read wind speed and direction from cursor and update view
            float windSpeedStr = data.getFloat(COL_WEATHER_WIND_SPEED);
            float windDirStr = data.getFloat(COL_WEATHER_DEGREES);
            mWindView.setText(Utility.getFormattedWind(getActivity(), windSpeedStr, windDirStr));

            mWindGraphic.setWindSpeed((int) windSpeedStr);
            mWindGraphic.setWindOriginDegrees(windDirStr);
            mWindGraphic.setForegroundColor(getResources().getColor(R.color.sunshine_light_blue));
            mWindGraphic.setBackgroundColor(getResources().getColor(R.color.sunshine_dark_blue));
...
    }
}